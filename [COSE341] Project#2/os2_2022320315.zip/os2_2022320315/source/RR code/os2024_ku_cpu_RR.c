// RR

#include <linux/sched.h>
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/linkage.h>
#include <linux/slab.h>
#include <linux/uaccess.h>
#include <linux/list.h>
#include <linux/mutex.h>

#define IDLE -1
#define TIME_SLICE 10 // 1초 (0.1초 * 10)

struct ku_cpu {
    pid_t pid;
    int job_time;
    int remaining_time;
    char name[4];
    struct list_head list; // 대기열을 위한 리스트
};

static struct ku_cpu *running_process = NULL;
static LIST_HEAD(waiting_queue);
static DEFINE_MUTEX(cpu_lock);

// RR 스케줄링 함수
struct ku_cpu* schedule_rr(void) {
    if (list_empty(&waiting_queue)) {
        return NULL;
    }
    return list_first_entry(&waiting_queue, struct ku_cpu, list);
}

SYSCALL_DEFINE2(os2024_ku_cpu, char*, name, int, jobTime) {
    struct ku_cpu *new_process, *temp;
    char proc_name[4];

    if (copy_from_user(proc_name, name, 4)) {
        printk(KERN_INFO "Copy from user failed for %s\n", proc_name);
        return -EFAULT;
    }

    mutex_lock(&cpu_lock);

    // 현재 실행 중인 프로세스가 없는 경우
    if (!running_process) {
        running_process = kmalloc(sizeof(struct ku_cpu), GFP_KERNEL);
        if (!running_process) {
            mutex_unlock(&cpu_lock);
            printk(KERN_INFO "Memory allocation failed for %s\n", proc_name);
            return -ENOMEM;
        }
        running_process->pid = current->pid;
        running_process->job_time = jobTime;
        running_process->remaining_time = jobTime;
        strncpy(running_process->name, proc_name, 4);
        printk(KERN_INFO "Working: %s\n", proc_name);
        mutex_unlock(&cpu_lock);
        return 0;
    }

    // 요청한 프로세스가 현재 실행 중인 프로세스인 경우
    if (running_process->pid == current->pid) {
        running_process->remaining_time = jobTime;
        if (jobTime == 0) {
            printk(KERN_INFO "Process finished: %s\n", proc_name);
            kfree(running_process);
            running_process = NULL;
            if (!list_empty(&waiting_queue)) {
                running_process = schedule_rr();
                if (running_process) {
                    list_del(&running_process->list);
                    printk(KERN_INFO "Turn Over ----> %s\n", running_process->name);
                    printk(KERN_INFO "Working: %s\n", running_process->name);
                }
            }
        } else if (running_process->remaining_time % TIME_SLICE == 0) {
            // 시간 슬라이스가 끝난 경우
            list_add_tail(&running_process->list, &waiting_queue);
            running_process = schedule_rr();
            if (running_process) {
                list_del(&running_process->list);
                printk(KERN_INFO "Turn Over ----> %s\n", running_process->name);
                printk(KERN_INFO "Working: %s\n", running_process->name);
            }
        }
        mutex_unlock(&cpu_lock);
        return 0;
    }

    // 요청한 프로세스가 대기열에 있는지 확인
    list_for_each_entry(temp, &waiting_queue, list) {
        if (temp->pid == current->pid) {
            printk(KERN_INFO "Working Denied: %s\n", proc_name);
            mutex_unlock(&cpu_lock);
            return 1;
        }
    }

    // 새로운 프로세스를 대기열에 추가
    new_process = kmalloc(sizeof(struct ku_cpu), GFP_KERNEL);
    if (!new_process) {
        mutex_unlock(&cpu_lock);
        printk(KERN_INFO "Memory allocation failed for %s\n", proc_name);
        return -ENOMEM;
    }
    new_process->pid = current->pid;
    new_process->job_time = jobTime;
    new_process->remaining_time = jobTime;
    strncpy(new_process->name, proc_name, 4);
    list_add_tail(&new_process->list, &waiting_queue);
    printk(KERN_INFO "Added to waiting queue: %s\n", proc_name);

    mutex_unlock(&cpu_lock);
    return 1;
}

SYSCALL_DEFINE1(os2024_pid_print, char*, name) {
    pid_t pid = current->pid;
    printk("Process name: %s pid: %d\n", name, pid);
    return 0;
}

