// RR

#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define KU_CPU 339         // ku_cpu 시스템 호출 번호
#define PID_PRINT 338      // pid_print 시스템 호출 번호

int main(int argc, char **argv) {
    int jobTime;
    int delayTime;
    char name[4];
    int wait = 0;
    int response_time = -1; // 응답 시간
    int first_run = 1; // 첫 번째 실행 여부

    if (argc < 4) {
        printf("\nInsufficient Arguments..\n");
        return 1;
    }

    jobTime = atoi(argv[1]);
    delayTime = atoi(argv[2]);
    strcpy(name, argv[3]);

    sleep(delayTime);
    printf("\nProcess %s : I will use CPU by %ds.\n", name, jobTime);

    // PID 출력 시스템 호출 사용
    printf("Calling PID_PRINT syscall for %s\n", name);
    syscall(PID_PRINT, name);

    jobTime *= 10; // execute system call in every 0.1 second

    while (jobTime) {
        int result = syscall(KU_CPU, name, jobTime);
        if (result == 0) {
            jobTime--;
            if (first_run) {
                response_time = wait; // 첫 번째 실행 시 대기 시간 저장
                first_run = 0;
            }
        } else {
            wait++;
        }
        usleep(100000); // delay 0.1 second
    }

    syscall(KU_CPU, name, 0);
    printf("\nProcess %s : Finish! My response time is %ds and My total wait time is %ds.\n", name, (response_time + 5) / 10, (wait + 5) / 10);
    return 0;
}

